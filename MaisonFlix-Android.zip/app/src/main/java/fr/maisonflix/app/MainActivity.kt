package fr.maisonflix.app

import android.content.Context
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("maisonflix", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFFE50914),
                    background = androidx.compose.ui.graphics.Color(0xFF090909),
                    surface = androidx.compose.ui.graphics.Color(0xFF151515)
                )
            ) {
                MaisonFlixApp()
            }
        }
    }

    @Composable
    fun MaisonFlixApp() {
        var server by remember { mutableStateOf(prefs.getString("server", "http://192.168.1.100:3000") ?: "") }
        var connected by remember { mutableStateOf(false) }

        if (!connected) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(28.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("MaisonFlix", style = MaterialTheme.typography.displaySmall)
                    Spacer(Modifier.height(8.dp))
                    Text("Votre cinéma à la maison")
                    Spacer(Modifier.height(28.dp))
                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it },
                        label = { Text("Adresse du serveur") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            prefs.edit().putString("server", server.trim().removeSuffix("/")).apply()
                            connected = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Se connecter") }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Exemple : http://192.168.1.100:3000",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.allowFileAccess = false
                        webViewClient = WebViewClient()
                        loadUrl(server.trim().removeSuffix("/"))
                    }
                }
            )
        }
    }
}
